<?php
	// Константы базы данных
	define("DB_SERVER", "localhost");
	define("DB_USER", "root");
	define("DB_PASS", "12345678");
	define("DB_NAME", "opd");
	?>