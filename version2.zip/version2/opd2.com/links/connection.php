<?php
	$con = mysqli_connect('localhost','root', '', 'opd', 3306) or die('Error');?>